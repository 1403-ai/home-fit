"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.getObjectFromS3 = getObjectFromS3;
const client_s3_1 = require("@aws-sdk/client-s3");
const s3 = new client_s3_1.S3Client({});
async function getObjectFromS3(bucket, key) {
    const response = await s3.send(new client_s3_1.GetObjectCommand({ Bucket: bucket, Key: key }));
    if (!response.Body) {
        throw new Error(`Empty response body for s3://${bucket}/${key}`);
    }
    const chunks = [];
    const stream = response.Body;
    for await (const chunk of stream) {
        chunks.push(chunk);
    }
    return Buffer.concat(chunks);
}
