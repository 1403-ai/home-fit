"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = handler;
const s3_client_1 = require("./s3-client");
const bedrock_client_1 = require("./bedrock-client");
const documentdb_client_1 = require("./documentdb-client");
async function handler(event, context) {
    console.log('PDF Analyzer Lambda invoked', JSON.stringify({ requestId: context.awsRequestId }));
    for (const record of event.Records) {
        const bucket = record.s3.bucket.name;
        const key = decodeURIComponent(record.s3.object.key.replace(/\+/g, ' '));
        console.log(`Processing: s3://${bucket}/${key}`);
        try {
            // 1. S3에서 PDF 파일 읽기
            const pdfBuffer = await (0, s3_client_1.getObjectFromS3)(bucket, key);
            console.log(`PDF downloaded: ${pdfBuffer.length} bytes`);
            // 2. Bedrock Claude Opus 4로 PDF 분석
            const analysisResult = await (0, bedrock_client_1.analyzePdfWithBedrock)(pdfBuffer, key);
            console.log(`Analysis complete: ${analysisResult.announcements.length} announcements found`);
            // 3. DocumentDB에 저장
            await (0, documentdb_client_1.saveToDocumentDB)(analysisResult);
            console.log(`Saved to DocumentDB successfully`);
        }
        catch (error) {
            console.error(`Error processing ${key}:`, error);
            throw error;
        }
    }
}
