"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.saveToDocumentDB = saveToDocumentDB;
const mongodb_1 = require("mongodb");
const fs = __importStar(require("fs"));
const path = __importStar(require("path"));
let cachedClient = null;
function getConnectionUri() {
    const endpoint = process.env.DOCDB_ENDPOINT;
    const port = process.env.DOCDB_PORT || '27017';
    const username = process.env.DOCDB_USERNAME;
    const password = process.env.DOCDB_PASSWORD;
    const database = process.env.DOCDB_DATABASE || 'homefit';
    if (!endpoint || !username || !password) {
        throw new Error('DocumentDB connection env vars required: DOCDB_ENDPOINT, DOCDB_USERNAME, DOCDB_PASSWORD');
    }
    return `mongodb://${username}:${password}@${endpoint}:${port}/${database}?tls=true&replicaSet=rs0&readPreference=secondaryPreferred&retryWrites=false`;
}
function getTlsCaFile() {
    // Lambda 환경에서는 /opt 또는 /tmp에 CA 번들을 배치
    const possiblePaths = [
        path.join(__dirname, 'global-bundle.pem'),
        '/opt/global-bundle.pem',
        '/tmp/global-bundle.pem'
    ];
    for (const p of possiblePaths) {
        if (fs.existsSync(p)) {
            return p;
        }
    }
    throw new Error('DocumentDB CA certificate not found');
}
async function getClient() {
    if (cachedClient) {
        return cachedClient;
    }
    const uri = getConnectionUri();
    const tlsCAFile = getTlsCaFile();
    cachedClient = new mongodb_1.MongoClient(uri, {
        tls: true,
        tlsCAFile,
        connectTimeoutMS: 10000,
        serverSelectionTimeoutMS: 10000,
        authMechanism: 'SCRAM-SHA-1'
    });
    await cachedClient.connect();
    return cachedClient;
}
async function saveToDocumentDB(result) {
    const client = await getClient();
    const db = client.db(process.env.DOCDB_DATABASE || 'homefit');
    // 1. 공고 목록 저장 (upsert by seq)
    if (result.announcements.length > 0) {
        const announcementsCol = db.collection('announcements');
        const bulkOps = result.announcements.map((announcement) => ({
            updateOne: {
                filter: { seq: announcement.seq },
                update: {
                    $set: {
                        ...announcement,
                        updated_at: new Date().toISOString()
                    }
                },
                upsert: true
            }
        }));
        await announcementsCol.bulkWrite(bulkOps);
        console.log(`Upserted ${result.announcements.length} announcements`);
    }
    // 2. Q&A 상태 머신 저장 (공고 seq 기준)
    if (result.qa_state_machine && result.announcements.length > 0) {
        const stateMachinesCol = db.collection('qa_state_machines');
        const seq = result.announcements[0].seq;
        await stateMachinesCol.updateOne({ announcement_seq: seq }, {
            $set: {
                announcement_seq: seq,
                ...result.qa_state_machine,
                updated_at: new Date().toISOString()
            }
        }, { upsert: true });
        console.log(`Upserted Q&A state machine for seq: ${seq}`);
    }
    // 3. 용어 사전 저장 (upsert by term)
    if (result.glossary.length > 0) {
        const glossaryCol = db.collection('glossary');
        const bulkOps = result.glossary.map((entry) => ({
            updateOne: {
                filter: { term: entry.term },
                update: {
                    $set: {
                        ...entry,
                        updated_at: new Date().toISOString()
                    }
                },
                upsert: true
            }
        }));
        await glossaryCol.bulkWrite(bulkOps);
        console.log(`Upserted ${result.glossary.length} glossary entries`);
    }
}
